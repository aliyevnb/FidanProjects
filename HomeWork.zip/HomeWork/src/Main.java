public class Main {
    public static void main(String[] args) {
        /*  Given a string, if the string "del" appears starting at index 1, return a string where that "del" has been deleted.
        Otherwise, return the string unchanged.

        delDel("adelbc") → "abc"
        delDel("adelHello") → "aHello"
        delDel("adedbc") → "adedbc"
        */

        System.out.println(StringParser.stringParser("adelbc"));
        System.out.println(StringParser.stringParser("adelHello"));
        System.out.println(StringParser.stringParser("adedbc"));
        System.out.println(StringParser.stringParser("adelreturnString"));
        System.out.println(StringParser.stringParser(""));

    }
}